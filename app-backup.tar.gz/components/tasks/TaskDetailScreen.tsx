import React, { useState } from 'react';
import { View, Text, ScrollView, TextInput, Alert } from 'react-native';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { ProgressBar } from '@/components/ui/ProgressBar';
import { Header } from '@/components/ui/Header';
import {
  MapPin,
  Calendar,
  User,
  Camera,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react-native';
import { Task } from '@/types';

interface TaskDetailScreenProps {
  task: Task;
  onBack?: () => void;
}

export function TaskDetailScreen({ task, onBack }: TaskDetailScreenProps) {
  const [progress, setProgress] = useState(task.progress.toString());
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);

  const statusVariant = {
    pending: 'warning' as const,
    in_progress: 'info' as const,
    completed: 'success' as const,
  };

  const priorityVariant = {
    low: 'default' as const,
    medium: 'warning' as const,
    high: 'danger' as const,
  };

  const handleStartTask = async () => {
    setLoading(true);
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000));
    Alert.alert('Success', 'Task started successfully!');
    setLoading(false);
  };

  const handleUpdateProgress = async () => {
    if (!progress || isNaN(Number(progress))) {
      Alert.alert('Error', 'Please enter a valid progress percentage');
      return;
    }

    setLoading(true);
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000));
    Alert.alert('Success', 'Progress updated successfully!');
    setLoading(false);
  };

  const handleCompleteTask = async () => {
    Alert.alert(
      'Complete Task',
      'Are you sure you want to mark this task as completed?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Complete',
          onPress: async () => {
            setLoading(true);
            await new Promise((resolve) => setTimeout(resolve, 1000));
            Alert.alert('Success', 'Task completed!');
            setLoading(false);
          },
        },
      ]
    );
  };

  return (
    <View className="flex-1 bg-gray-50">
      <Header title="Task Details" />
      <ScrollView className="flex-1" contentContainerClassName="p-4">
        {/* Task Header */}
        <Card className="mb-4">
          <View className="flex-row items-start justify-between mb-3">
            <View className="flex-1 mr-2">
              <Text className="text-xl font-bold text-gray-900 mb-2">{task.title}</Text>
              <View className="flex-row gap-2">
                <Badge variant={priorityVariant[task.priority]} size="sm">
                  {task.priority}
                </Badge>
                <Badge variant={statusVariant[task.status]} size="sm">
                  {task.status.replace('_', ' ')}
                </Badge>
              </View>
            </View>
          </View>

          <Text className="text-base text-gray-700 mb-4">{task.description}</Text>

          {/* Task Info */}
          <View className="space-y-3">
            <View className="flex-row items-center py-2 border-t border-gray-200">
              <MapPin size={18} color="#6B7280" />
              <View className="ml-3 flex-1">
                <Text className="text-xs text-gray-600">Site</Text>
                <Text className="text-sm font-semibold text-gray-900">{task.siteName}</Text>
              </View>
            </View>

            <View className="flex-row items-center py-2 border-t border-gray-200">
              <Calendar size={18} color="#6B7280" />
              <View className="ml-3 flex-1">
                <Text className="text-xs text-gray-600">Due Date</Text>
                <Text className="text-sm font-semibold text-gray-900">{task.dueDate}</Text>
              </View>
            </View>

            <View className="flex-row items-center py-2 border-t border-gray-200">
              <User size={18} color="#6B7280" />
              <View className="ml-3 flex-1">
                <Text className="text-xs text-gray-600">Created</Text>
                <Text className="text-sm font-semibold text-gray-900">{task.createdAt}</Text>
              </View>
            </View>
          </View>
        </Card>

        {/* Progress Card */}
        <Card className="mb-4">
          <Text className="text-lg font-bold text-gray-900 mb-3">Progress</Text>
          <ProgressBar progress={task.progress} />

          {task.status === 'in_progress' && (
            <View className="mt-4">
              <Text className="text-sm font-medium text-gray-700 mb-2">Update Progress (%)</Text>
              <TextInput
                className="border border-gray-300 rounded-lg px-4 py-3 text-base text-gray-900 bg-white mb-3"
                placeholder="Enter progress percentage"
                value={progress}
                onChangeText={setProgress}
                keyboardType="numeric"
              />
              <Button onPress={handleUpdateProgress} loading={loading}>
                Save Progress
              </Button>
            </View>
          )}
        </Card>

        {/* Notes Card */}
        {task.status === 'in_progress' && (
          <Card className="mb-4">
            <Text className="text-lg font-bold text-gray-900 mb-3">Add Notes</Text>
            <TextInput
              className="border border-gray-300 rounded-lg px-4 py-3 text-base text-gray-900 bg-white mb-3"
              placeholder="Enter task notes or observations..."
              value={notes}
              onChangeText={setNotes}
              multiline
              numberOfLines={4}
              textAlignVertical="top"
            />
            <Button variant="outline">
              <View className="flex-row items-center">
                <Camera size={18} color="#2563eb" />
                <Text className="text-blue-600 font-semibold ml-2">Add Photo</Text>
              </View>
            </Button>
          </Card>
        )}

        {/* Actions */}
        <Card className="mb-6">
          <Text className="text-lg font-bold text-gray-900 mb-3">Actions</Text>
          
          {task.status === 'pending' && (
            <Button onPress={handleStartTask} loading={loading} className="mb-3">
              <View className="flex-row items-center">
                <AlertCircle size={18} color="#ffffff" />
                <Text className="text-white font-semibold ml-2">Start Task</Text>
              </View>
            </Button>
          )}

          {task.status === 'in_progress' && (
            <Button
              variant="primary"
              onPress={handleCompleteTask}
              loading={loading}
              className="bg-green-600 active:bg-green-700"
            >
              <View className="flex-row items-center">
                <CheckCircle2 size={18} color="#ffffff" />
                <Text className="text-white font-semibold ml-2">Complete Task</Text>
              </View>
            </Button>
          )}

          {task.status === 'completed' && (
            <View className="bg-green-50 rounded-lg p-4 items-center">
              <CheckCircle2 size={32} color="#10B981" />
              <Text className="text-green-800 font-semibold mt-2">Task Completed</Text>
              <Text className="text-green-600 text-sm mt-1">
                Finished on {task.updatedAt}
              </Text>
            </View>
          )}
        </Card>
      </ScrollView>
    </View>
  );
}

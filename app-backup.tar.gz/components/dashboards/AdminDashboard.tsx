import React from 'react';
import { View, Text, ScrollView } from 'react-native';
import { Card } from '@/components/ui/Card';
import { SiteCard } from '@/components/sites/SiteCard';
import { Header } from '@/components/ui/Header';
import { mockSites } from '@/data/mockData';
import {
  Building2,
  DollarSign,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react-native';

export function AdminDashboard() {
  const totalBudget = mockSites.reduce((sum, site) => sum + site.budget, 0);
  const totalSpent = mockSites.reduce((sum, site) => sum + site.spent, 0);
  const activeSites = mockSites.filter((s) => s.status === 'active').length;

  const stats = [
    {
      icon: <Building2 size={24} color="#3B82F6" />,
      label: 'Active Sites',
      value: activeSites.toString(),
      bg: 'bg-blue-50',
    },
    {
      icon: <DollarSign size={24} color="#10B981" />,
      label: 'Total Budget',
      value: `${(totalBudget / 1000000).toFixed(1)}M`,
      bg: 'bg-green-50',
    },
    {
      icon: <CheckCircle2 size={24} color="#8B5CF6" />,
      label: 'Total Spent',
      value: `${(totalSpent / 1000000).toFixed(1)}M`,
      bg: 'bg-purple-50',
    },
    {
      icon: <AlertTriangle size={24} color="#F59E0B" />,
      label: 'Remaining',
      value: `${((totalBudget - totalSpent) / 1000000).toFixed(1)}M`,
      bg: 'bg-yellow-50',
    },
  ];

  return (
    <View className="flex-1 bg-gray-50">
      <Header title="Admin Dashboard" subtitle="Overview of all operations" />
      <ScrollView className="flex-1" contentContainerClassName="p-4">
        {/* Stats Grid */}
        <View className="flex-row flex-wrap -mx-1 mb-4">
          {stats.map((stat, index) => (
            <View key={index} className="w-1/2 p-1">
              <Card className={stat.bg}>
                <View className="items-center py-2">
                  {stat.icon}
                  <Text className="text-2xl font-bold text-gray-900 mt-2">{stat.value}</Text>
                  <Text className="text-xs text-gray-600 mt-1">{stat.label}</Text>
                </View>
              </Card>
            </View>
          ))}
        </View>

        {/* Sites Section */}
        <View className="mb-4">
          <Text className="text-lg font-bold text-gray-900 mb-3">All Sites</Text>
          {mockSites.map((site) => (
            <SiteCard key={site.id} site={site} />
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

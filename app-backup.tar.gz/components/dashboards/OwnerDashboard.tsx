import React from 'react';
import { View, Text, ScrollView } from 'react-native';
import { Card } from '@/components/ui/Card';
import { SiteCard } from '@/components/sites/SiteCard';
import { Header } from '@/components/ui/Header';
import { mockSites } from '@/data/mockData';
import { TrendingUp, TrendingDown, DollarSign, PieChart } from 'lucide-react-native';

export function OwnerDashboard() {
  const totalBudget = mockSites.reduce((sum, site) => sum + site.budget, 0);
  const totalSpent = mockSites.reduce((sum, site) => sum + site.spent, 0);
  const remaining = totalBudget - totalSpent;
  const utilizationRate = (totalSpent / totalBudget) * 100;

  return (
    <View className="flex-1 bg-gray-50">
      <Header title="Financial Overview" subtitle="Business Owner Dashboard" />
      <ScrollView className="flex-1" contentContainerClassName="p-4">
        {/* Financial Summary */}
        <Card className="mb-4 bg-gradient-to-br from-blue-600 to-blue-700">
          <View className="py-2">
            <Text className="text-white text-sm font-medium mb-2">Total Investment</Text>
            <Text className="text-white text-4xl font-bold mb-4">
              RWF {(totalBudget / 1000000).toFixed(1)}M
            </Text>
            <View className="flex-row justify-between pt-3 border-t border-blue-500">
              <View>
                <Text className="text-blue-200 text-xs">Spent</Text>
                <Text className="text-white text-lg font-semibold">
                  {(totalSpent / 1000000).toFixed(1)}M
                </Text>
              </View>
              <View>
                <Text className="text-blue-200 text-xs">Remaining</Text>
                <Text className="text-white text-lg font-semibold">
                  {(remaining / 1000000).toFixed(1)}M
                </Text>
              </View>
              <View>
                <Text className="text-blue-200 text-xs">Utilization</Text>
                <Text className="text-white text-lg font-semibold">
                  {utilizationRate.toFixed(0)}%
                </Text>
              </View>
            </View>
          </View>
        </Card>

        {/* Key Metrics */}
        <View className="flex-row mb-4 gap-3">
          <Card className="flex-1 bg-green-50">
            <View className="items-center py-3">
              <TrendingUp size={28} color="#10B981" />
              <Text className="text-xl font-bold text-gray-900 mt-2">
                {mockSites.filter((s) => s.status === 'active').length}
              </Text>
              <Text className="text-xs text-gray-600 mt-1">Active Sites</Text>
            </View>
          </Card>
          <Card className="flex-1 bg-purple-50">
            <View className="items-center py-3">
              <PieChart size={28} color="#8B5CF6" />
              <Text className="text-xl font-bold text-gray-900 mt-2">
                {(mockSites.reduce((sum, s) => sum + s.progress, 0) / mockSites.length).toFixed(0)}
                %
              </Text>
              <Text className="text-xs text-gray-600 mt-1">Avg Progress</Text>
            </View>
          </Card>
        </View>

        {/* Sites Performance */}
        <View className="mb-4">
          <Text className="text-lg font-bold text-gray-900 mb-3">Site Performance</Text>
          {mockSites.map((site) => (
            <SiteCard key={site.id} site={site} />
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

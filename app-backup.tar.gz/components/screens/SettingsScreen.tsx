import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { Card } from '@/components/ui/Card';
import { Header } from '@/components/ui/Header';
import { Button } from '@/components/ui/Button';
import { useAuth } from '@/context/AuthContext';
import { User, Settings as SettingsIcon, Bell, Globe, LogOut } from 'lucide-react-native';

export function SettingsScreen() {
  const { user, logout } = useAuth();
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);

  const handleLogout = () => {
    Alert.alert(
      'Confirm Logout',
      'Are you sure you want to sign out?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Logout',
          style: 'destructive',
          onPress: logout,
        },
      ]
    );
  };

  return (
    <View className="flex-1 bg-gray-50">
      <Header title="Settings" subtitle="Manage your preferences" />
      <ScrollView className="flex-1" contentContainerClassName="p-4">
        {/* Profile Section */}
        <Card className="mb-4">
          <View className="items-center py-4">
            <View className="w-20 h-20 bg-blue-600 rounded-full items-center justify-center mb-3">
              <User size={40} color="#ffffff" />
            </View>
            <Text className="text-xl font-bold text-gray-900">{user?.name}</Text>
            <Text className="text-sm text-gray-600 mt-1">{user?.email}</Text>
            <View className="bg-blue-100 px-3 py-1 rounded-full mt-2">
              <Text className="text-xs font-semibold text-blue-800 uppercase">{user?.role}</Text>
            </View>
          </View>
        </Card>

        {/* Settings Options */}
        <View className="mb-4">
          <Text className="text-lg font-bold text-gray-900 mb-3">Preferences</Text>

          <Card className="mb-3">
            <TouchableOpacity className="flex-row items-center py-2">
              <View className="w-10 h-10 bg-blue-50 rounded-lg items-center justify-center mr-3">
                <User size={20} color="#3B82F6" />
              </View>
              <View className="flex-1">
                <Text className="text-base font-semibold text-gray-900">Edit Profile</Text>
                <Text className="text-xs text-gray-600">Update your personal information</Text>
              </View>
            </TouchableOpacity>
          </Card>

          <Card className="mb-3">
            <TouchableOpacity 
              className="flex-row items-center py-2"
              onPress={() => setNotificationsEnabled(!notificationsEnabled)}
            >
              <View className="w-10 h-10 bg-yellow-50 rounded-lg items-center justify-center mr-3">
                <Bell size={20} color="#F59E0B" />
              </View>
              <View className="flex-1">
                <Text className="text-base font-semibold text-gray-900">Notifications</Text>
                <Text className="text-xs text-gray-600">
                  {notificationsEnabled ? 'Enabled' : 'Disabled'}
                </Text>
              </View>
            </TouchableOpacity>
          </Card>

          <Card className="mb-3">
            <TouchableOpacity className="flex-row items-center py-2">
              <View className="w-10 h-10 bg-green-50 rounded-lg items-center justify-center mr-3">
                <Globe size={20} color="#10B981" />
              </View>
              <View className="flex-1">
                <Text className="text-base font-semibold text-gray-900">Language</Text>
                <Text className="text-xs text-gray-600">English</Text>
              </View>
            </TouchableOpacity>
          </Card>
        </View>

        {/* About Section */}
        <View className="mb-4">
          <Text className="text-lg font-bold text-gray-900 mb-3">About</Text>
          <Card>
            <View className="py-2">
              <View className="flex-row justify-between mb-2">
                <Text className="text-sm text-gray-600">Version</Text>
                <Text className="text-sm font-semibold text-gray-900">1.0.0</Text>
              </View>
              <View className="flex-row justify-between mb-2">
                <Text className="text-sm text-gray-600">Company</Text>
                <Text className="text-sm font-semibold text-gray-900">HapyJo Ltd</Text>
              </View>
              <View className="flex-row justify-between">
                <Text className="text-sm text-gray-600">Support</Text>
                <Text className="text-sm font-semibold text-blue-600">support@hapyjo.rw</Text>
              </View>
            </View>
          </Card>
        </View>

        {/* Logout Button */}
        <Button variant="danger" onPress={handleLogout} className="mb-6">
          <View className="flex-row items-center">
            <LogOut size={18} color="#ffffff" />
            <Text className="text-white font-semibold ml-2">Sign Out</Text>
          </View>
        </Button>
      </ScrollView>
    </View>
  );
}

import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity } from 'react-native';
import { Card } from '@/components/ui/Card';
import { Header } from '@/components/ui/Header';
import { Button } from '@/components/ui/Button';
import { useAuth } from '@/context/AuthContext';
import { mockReports, mockSites } from '@/data/mockData';
import {
  FileText,
  TrendingUp,
  DollarSign,
  BarChart3,
  Download,
} from 'lucide-react-native';

export function ReportsScreen() {
  const { user } = useAuth();
  const [selectedType, setSelectedType] = useState<'all' | 'financial' | 'operations' | 'site_performance'>('all');

  const filteredReports = selectedType === 'all' 
    ? mockReports 
    : mockReports.filter(r => r.type === selectedType);

  const reportTypes = [
    { id: 'all', label: 'All', icon: <FileText size={18} color="#6B7280" /> },
    { id: 'financial', label: 'Financial', icon: <DollarSign size={18} color="#10B981" /> },
    { id: 'operations', label: 'Operations', icon: <BarChart3 size={18} color="#3B82F6" /> },
    { id: 'site_performance', label: 'Site Performance', icon: <TrendingUp size={18} color="#8B5CF6" /> },
  ];

  const totalBudget = mockSites.reduce((sum, site) => sum + site.budget, 0);
  const totalSpent = mockSites.reduce((sum, site) => sum + site.spent, 0);

  return (
    <View className="flex-1 bg-gray-50">
      <Header 
        title="Reports" 
        subtitle={user?.role === 'owner' ? 'Business insights' : 'Operations analytics'}
      />
      <ScrollView className="flex-1" contentContainerClassName="p-4">
        {/* Filter Tabs */}
        <ScrollView 
          horizontal 
          showsHorizontalScrollIndicator={false}
          className="mb-4"
        >
          <View className="flex-row gap-2">
            {reportTypes.map((type) => (
              <TouchableOpacity
                key={type.id}
                onPress={() => setSelectedType(type.id as any)}
                className={`px-4 py-2 rounded-lg flex-row items-center ${
                  selectedType === type.id 
                    ? 'bg-blue-600' 
                    : 'bg-white border border-gray-300'
                }`}
              >
                {type.icon}
                <Text 
                  className={`ml-2 font-semibold ${
                    selectedType === type.id ? 'text-white' : 'text-gray-700'
                  }`}
                >
                  {type.label}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </ScrollView>

        {/* Summary Cards */}
        {user?.role === 'owner' || user?.role === 'admin' ? (
          <View className="mb-4">
            <Card className="bg-gradient-to-r from-blue-600 to-blue-700 mb-3">
              <View className="py-2">
                <View className="flex-row items-center mb-2">
                  <DollarSign size={24} color="#ffffff" />
                  <Text className="text-white text-base font-semibold ml-2">Financial Summary</Text>
                </View>
                <Text className="text-white text-3xl font-bold mb-3">
                  RWF {(totalBudget / 1000000).toFixed(1)}M
                </Text>
                <View className="flex-row justify-between pt-3 border-t border-blue-500">
                  <View>
                    <Text className="text-blue-200 text-xs">Total Spent</Text>
                    <Text className="text-white text-lg font-semibold">
                      {(totalSpent / 1000000).toFixed(1)}M
                    </Text>
                  </View>
                  <View>
                    <Text className="text-blue-200 text-xs">Remaining</Text>
                    <Text className="text-white text-lg font-semibold">
                      {((totalBudget - totalSpent) / 1000000).toFixed(1)}M
                    </Text>
                  </View>
                  <View>
                    <Text className="text-blue-200 text-xs">Utilization</Text>
                    <Text className="text-white text-lg font-semibold">
                      {((totalSpent / totalBudget) * 100).toFixed(0)}%
                    </Text>
                  </View>
                </View>
              </View>
            </Card>
          </View>
        ) : null}

        {/* Reports List */}
        <View className="mb-4">
          <Text className="text-lg font-bold text-gray-900 mb-3">Available Reports</Text>
          {filteredReports.map((report) => (
            <Card key={report.id} className="mb-3">
              <View className="flex-row items-start justify-between mb-2">
                <View className="flex-1">
                  <Text className="text-base font-bold text-gray-900 mb-1">{report.title}</Text>
                  <Text className="text-xs text-gray-600 capitalize">{report.type.replace('_', ' ')}</Text>
                </View>
                <View className="bg-blue-100 px-2 py-1 rounded">
                  <Text className="text-xs font-semibold text-blue-800">{report.period}</Text>
                </View>
              </View>

              <View className="bg-gray-50 rounded p-3 my-3">
                {report.type === 'financial' && report.data && (
                  <View>
                    <View className="flex-row justify-between mb-2">
                      <Text className="text-sm text-gray-600">Total Budget</Text>
                      <Text className="text-sm font-semibold text-gray-900">
                        RWF {(report.data.totalBudget / 1000000).toFixed(1)}M
                      </Text>
                    </View>
                    <View className="flex-row justify-between mb-2">
                      <Text className="text-sm text-gray-600">Total Spent</Text>
                      <Text className="text-sm font-semibold text-gray-900">
                        RWF {(report.data.totalSpent / 1000000).toFixed(1)}M
                      </Text>
                    </View>
                    <View className="flex-row justify-between">
                      <Text className="text-sm text-gray-600">Remaining</Text>
                      <Text className="text-sm font-semibold text-green-600">
                        RWF {(report.data.remainingBudget / 1000000).toFixed(1)}M
                      </Text>
                    </View>
                  </View>
                )}
                {report.type === 'operations' && report.data && (
                  <View>
                    <View className="flex-row justify-between mb-2">
                      <Text className="text-sm text-gray-600">Active Sites</Text>
                      <Text className="text-sm font-semibold text-gray-900">{report.data.activeSites}</Text>
                    </View>
                    <View className="flex-row justify-between mb-2">
                      <Text className="text-sm text-gray-600">Completed Tasks</Text>
                      <Text className="text-sm font-semibold text-green-600">{report.data.completedTasks}</Text>
                    </View>
                    <View className="flex-row justify-between">
                      <Text className="text-sm text-gray-600">Pending Tasks</Text>
                      <Text className="text-sm font-semibold text-yellow-600">{report.data.pendingTasks}</Text>
                    </View>
                  </View>
                )}
              </View>

              <View className="flex-row items-center justify-between pt-3 border-t border-gray-200">
                <Text className="text-xs text-gray-600">Generated: {report.generatedDate}</Text>
                <TouchableOpacity className="flex-row items-center">
                  <Download size={16} color="#3B82F6" />
                  <Text className="text-sm text-blue-600 font-semibold ml-1">Export</Text>
                </TouchableOpacity>
              </View>
            </Card>
          ))}
        </View>

        {/* Generate New Report */}
        <Card className="bg-blue-50 mb-4">
          <View className="py-2">
            <Text className="text-base font-bold text-gray-900 mb-2">Generate Custom Report</Text>
            <Text className="text-sm text-gray-600 mb-4">
              Create a custom report with specific date ranges and filters
            </Text>
            <Button>Generate Report</Button>
          </View>
        </Card>
      </ScrollView>
    </View>
  );
}

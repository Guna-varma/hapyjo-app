import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, TextInput } from 'react-native';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { Header } from '@/components/ui/Header';
import { EmptyState } from '@/components/ui/EmptyState';
import { User, Mail, Phone, MapPin, Plus, Search, Edit2 } from 'lucide-react-native';

interface UserData {
  id: string;
  name: string;
  email: string;
  role: string;
  phone?: string;
  active: boolean;
  siteAccess?: string[];
}

const mockUsers: UserData[] = [
  {
    id: '1',
    name: 'Admin User',
    email: 'admin@hapyjo.rw',
    role: 'admin',
    phone: '+250 788 123 456',
    active: true,
  },
  {
    id: '2',
    name: 'Business Owner',
    email: 'owner@hapyjo.rw',
    role: 'owner',
    phone: '+250 788 234 567',
    active: true,
  },
  {
    id: '3',
    name: 'John Driver',
    email: 'driver@hapyjo.rw',
    role: 'driver',
    phone: '+250 788 345 678',
    active: true,
    siteAccess: ['Kigali-Rwamagana Highway', 'Musanze Road Expansion'],
  },
  {
    id: '4',
    name: 'Mary Surveyor',
    email: 'surveyor@hapyjo.rw',
    role: 'surveyor',
    phone: '+250 788 456 789',
    active: true,
    siteAccess: ['Kigali-Rwamagana Highway'],
  },
  {
    id: '5',
    name: 'Tom Manager',
    email: 'manager@hapyjo.rw',
    role: 'site_manager',
    phone: '+250 788 567 890',
    active: false,
  },
];

export function UsersScreen() {
  const [searchQuery, setSearchQuery] = useState('');
  const [users] = useState<UserData[]>(mockUsers);

  const filteredUsers = users.filter(
    (user) =>
      user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.role.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getRoleBadgeVariant = (role: string) => {
    const variants: Record<string, 'success' | 'info' | 'warning' | 'default'> = {
      admin: 'success',
      owner: 'info',
      driver: 'warning',
      surveyor: 'warning',
      site_manager: 'info',
    };
    return variants[role] || 'default';
  };

  return (
    <View className="flex-1 bg-gray-50">
      <Header
        title="User Management"
        subtitle="Manage system users"
        rightAction={
          <TouchableOpacity className="bg-blue-600 rounded-lg px-4 py-2 flex-row items-center">
            <Plus size={18} color="#ffffff" />
            <Text className="text-white font-semibold ml-1">Add</Text>
          </TouchableOpacity>
        }
      />
      <ScrollView className="flex-1" contentContainerClassName="p-4">
        {/* Search Bar */}
        <View className="mb-4">
          <View className="bg-white rounded-lg border border-gray-300 flex-row items-center px-4 py-3">
            <Search size={20} color="#9CA3AF" />
            <TextInput
              className="flex-1 ml-3 text-base text-gray-900"
              placeholder="Search users..."
              value={searchQuery}
              onChangeText={setSearchQuery}
              placeholderTextColor="#9CA3AF"
            />
          </View>
        </View>

        {/* Stats */}
        <View className="flex-row mb-4 gap-3">
          <Card className="flex-1 bg-blue-50">
            <View className="items-center py-2">
              <Text className="text-2xl font-bold text-gray-900">
                {users.filter((u) => u.active).length}
              </Text>
              <Text className="text-xs text-gray-600">Active Users</Text>
            </View>
          </Card>
          <Card className="flex-1 bg-gray-100">
            <View className="items-center py-2">
              <Text className="text-2xl font-bold text-gray-900">
                {users.filter((u) => !u.active).length}
              </Text>
              <Text className="text-xs text-gray-600">Inactive Users</Text>
            </View>
          </Card>
          <Card className="flex-1 bg-purple-50">
            <View className="items-center py-2">
              <Text className="text-2xl font-bold text-gray-900">{users.length}</Text>
              <Text className="text-xs text-gray-600">Total Users</Text>
            </View>
          </Card>
        </View>

        {/* Users List */}
        <View className="mb-4">
          <Text className="text-lg font-bold text-gray-900 mb-3">All Users</Text>
          {filteredUsers.length > 0 ? (
            filteredUsers.map((user) => (
              <Card key={user.id} className="mb-3">
                <View className="flex-row items-start justify-between mb-3">
                  <View className="flex-row flex-1">
                    <View className="w-12 h-12 bg-blue-100 rounded-full items-center justify-center mr-3">
                      <User size={24} color="#3B82F6" />
                    </View>
                    <View className="flex-1">
                      <Text className="text-base font-bold text-gray-900">{user.name}</Text>
                      <View className="flex-row items-center mt-1 gap-2">
                        <Badge variant={getRoleBadgeVariant(user.role)} size="sm">
                          {user.role.replace('_', ' ')}
                        </Badge>
                        <Badge variant={user.active ? 'success' : 'default'} size="sm">
                          {user.active ? 'Active' : 'Inactive'}
                        </Badge>
                      </View>
                    </View>
                  </View>
                  <TouchableOpacity className="p-2">
                    <Edit2 size={18} color="#6B7280" />
                  </TouchableOpacity>
                </View>

                <View className="space-y-2">
                  <View className="flex-row items-center">
                    <Mail size={14} color="#6B7280" />
                    <Text className="text-sm text-gray-600 ml-2">{user.email}</Text>
                  </View>
                  {user.phone && (
                    <View className="flex-row items-center">
                      <Phone size={14} color="#6B7280" />
                      <Text className="text-sm text-gray-600 ml-2">{user.phone}</Text>
                    </View>
                  )}
                  {user.siteAccess && user.siteAccess.length > 0 && (
                    <View className="flex-row items-start mt-2">
                      <MapPin size={14} color="#6B7280" className="mt-0.5" />
                      <View className="flex-1 ml-2">
                        <Text className="text-xs text-gray-600">Site Access:</Text>
                        {user.siteAccess.map((site, index) => (
                          <Text key={index} className="text-sm text-gray-900 mt-0.5">
                            • {site}
                          </Text>
                        ))}
                      </View>
                    </View>
                  )}
                </View>
              </Card>
            ))
          ) : (
            <EmptyState
              icon={<User size={48} color="#9CA3AF" />}
              title="No users found"
              message="Try adjusting your search criteria"
            />
          )}
        </View>
      </ScrollView>
    </View>
  );
}

import React, { useState } from 'react';
import { View, Text, TouchableOpacity, SafeAreaView } from 'react-native';
import { useAuth } from '@/context/AuthContext';
import { RoleBasedDashboard } from '@/components/RoleBasedDashboard';
import { ReportsScreen } from '@/components/screens/ReportsScreen';
import { SettingsScreen } from '@/components/screens/SettingsScreen';
import { UsersScreen } from '@/components/screens/UsersScreen';
import {
  LayoutDashboard,
  FileText,
  Settings,
  ClipboardList,
  Users,
} from 'lucide-react-native';

type TabId = 'dashboard' | 'reports' | 'tasks' | 'users' | 'settings';

interface Tab {
  id: TabId;
  label: string;
  icon: typeof LayoutDashboard;
  roles?: string[];
}

export function AppNavigation() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<TabId>('dashboard');

  const tabs: Tab[] = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: LayoutDashboard,
    },
    {
      id: 'reports',
      label: 'Reports',
      icon: FileText,
      roles: ['admin', 'owner'],
    },
    {
      id: 'tasks',
      label: 'Tasks',
      icon: ClipboardList,
      roles: ['driver', 'surveyor', 'site_manager', 'foreman'],
    },
    {
      id: 'users',
      label: 'Users',
      icon: Users,
      roles: ['admin'],
    },
    {
      id: 'settings',
      label: 'Settings',
      icon: Settings,
    },
  ];

  const visibleTabs = tabs.filter((tab) => {
    if (!tab.roles) return true;
    return user && tab.roles.includes(user.role);
  });

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <RoleBasedDashboard />;
      case 'reports':
        return <ReportsScreen />;
      case 'tasks':
        return <RoleBasedDashboard />;
      case 'users':
        return <UsersScreen />;
      case 'settings':
        return <SettingsScreen />;
      default:
        return <RoleBasedDashboard />;
    }
  };

  return (
    <SafeAreaView className="flex-1 bg-gray-50">
      <View className="flex-1">
        {renderContent()}
      </View>

      {/* Bottom Tab Bar */}
      <View className="bg-white border-t border-gray-200 shadow-lg">
        <View className="flex-row justify-around px-2 py-2">
          {visibleTabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            
            return (
              <TouchableOpacity
                key={tab.id}
                onPress={() => setActiveTab(tab.id)}
                className="flex-1 items-center py-2"
                activeOpacity={0.7}
              >
                <View
                  className={`items-center justify-center ${
                    isActive ? 'bg-blue-50' : ''
                  } rounded-lg px-3 py-1`}
                >
                  <Icon
                    size={24}
                    color={isActive ? '#2563EB' : '#6B7280'}
                    strokeWidth={isActive ? 2.5 : 2}
                  />
                  <Text
                    className={`text-xs mt-1 font-medium ${
                      isActive ? 'text-blue-600' : 'text-gray-600'
                    }`}
                  >
                    {tab.label}
                  </Text>
                </View>
              </TouchableOpacity>
            );
          })}
        </View>
      </View>
    </SafeAreaView>
  );
}

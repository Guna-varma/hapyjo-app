import React from 'react';
import { View } from 'react-native';
import { useAuth } from '@/context/AuthContext';
import { AdminDashboard } from '@/components/dashboards/AdminDashboard';
import { OwnerDashboard } from '@/components/dashboards/OwnerDashboard';
import { DriverDashboard } from '@/components/dashboards/DriverDashboard';
import { SurveyorDashboard } from '@/components/dashboards/SurveyorDashboard';
import { UserRole } from '@/types';

export function RoleBasedDashboard() {
  const { user } = useAuth();

  if (!user) {
    return <View className="flex-1 bg-gray-50" />;
  }

  const dashboards: Record<UserRole, React.ComponentType> = {
    admin: AdminDashboard,
    owner: OwnerDashboard,
    driver: DriverDashboard,
    surveyor: SurveyorDashboard,
    site_manager: AdminDashboard, // Fallback to admin view
    accountant: OwnerDashboard, // Fallback to owner view
    engineer: AdminDashboard, // Fallback to admin view
    foreman: AdminDashboard, // Fallback to admin view
  };

  const DashboardComponent = dashboards[user.role] || AdminDashboard;

  return <DashboardComponent />;
}

import React from 'react';
import { View, Text } from 'react-native';

interface HeaderProps {
  title: string;
  subtitle?: string;
  rightAction?: React.ReactNode;
}

export function Header({ title, subtitle, rightAction }: HeaderProps) {
  return (
    <View className="bg-white border-b border-gray-200 px-4 py-4 shadow-sm">
      <View className="flex-row items-center justify-between">
        <View className="flex-1">
          <Text className="text-xl font-bold text-gray-900">{title}</Text>
          {subtitle && <Text className="text-sm text-gray-600 mt-0.5">{subtitle}</Text>}
        </View>
        {rightAction && <View className="ml-3">{rightAction}</View>}
      </View>
    </View>
  );
}

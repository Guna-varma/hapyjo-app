import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  Image,
  Alert,
} from 'react-native';
import { useAuth } from '@/context/AuthContext';
import { Button } from '@/components/ui/Button';

export function LoginScreen() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();

  const handleLogin = async () => {
    if (!email || !password) {
      Alert.alert('Error', 'Please enter both email and password');
      return;
    }

    setLoading(true);
    try {
      await login(email.trim(), password);
    } catch (error) {
      Alert.alert('Login Failed', 'Invalid email or password');
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      className="flex-1 bg-gray-50"
    >
      <ScrollView
        contentContainerClassName="flex-grow justify-center p-6"
        keyboardShouldPersistTaps="handled"
      >
        <View className="items-center mb-8">
          <View className="w-20 h-20 bg-blue-600 rounded-2xl items-center justify-center mb-4">
            <Text className="text-white text-3xl font-bold">H</Text>
          </View>
          <Text className="text-3xl font-bold text-gray-900">HapyJo Ltd</Text>
          <Text className="text-base text-gray-600 mt-2">Road Construction Management</Text>
        </View>

        <View className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
          <Text className="text-xl font-semibold text-gray-900 mb-6">Sign In</Text>

          <View className="mb-4">
            <Text className="text-sm font-medium text-gray-700 mb-2">Email</Text>
            <TextInput
              className="border border-gray-300 rounded-lg px-4 py-3 text-base text-gray-900 bg-white"
              placeholder="you@example.com"
              placeholderTextColor="#9CA3AF"
              value={email}
              onChangeText={setEmail}
              keyboardType="email-address"
              autoCapitalize="none"
              autoCorrect={false}
            />
          </View>

          <View className="mb-6">
            <Text className="text-sm font-medium text-gray-700 mb-2">Password</Text>
            <TextInput
              className="border border-gray-300 rounded-lg px-4 py-3 text-base text-gray-900 bg-white"
              placeholder="Enter your password"
              placeholderTextColor="#9CA3AF"
              value={password}
              onChangeText={setPassword}
              secureTextEntry
            />
          </View>

          <Button onPress={handleLogin} loading={loading} className="mb-4">
            Sign In
          </Button>

          <View className="mt-6 p-4 bg-blue-50 rounded-lg">
            <Text className="text-xs font-semibold text-blue-900 mb-2">Demo Accounts:</Text>
            <Text className="text-xs text-blue-800">Admin: admin@hapyjo.rw</Text>
            <Text className="text-xs text-blue-800">Owner: owner@hapyjo.rw</Text>
            <Text className="text-xs text-blue-800">Driver: driver@hapyjo.rw</Text>
            <Text className="text-xs text-blue-800">Surveyor: surveyor@hapyjo.rw</Text>
            <Text className="text-xs text-blue-700 mt-2 italic">Password: any</Text>
          </View>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

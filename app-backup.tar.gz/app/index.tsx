import React from 'react';
import { View } from 'react-native';
import { AuthProvider, useAuth } from '@/context/AuthContext';
import { LoginScreen } from '@/components/auth/LoginScreen';
import { AppNavigation } from '@/components/navigation/AppNavigation';
import '../global.css';

function AppContent() {
  const { isAuthenticated } = useAuth();

  if (!isAuthenticated) {
    return <LoginScreen />;
  }

  return <AppNavigation />;
}

export default function HomeScreen() {
  return (
    <AuthProvider>
      <View className="flex-1">
        <AppContent />
      </View>
    </AuthProvider>
  );
}

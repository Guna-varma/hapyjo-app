export type UserRole = 
  | 'admin' 
  | 'owner' 
  | 'driver' 
  | 'surveyor' 
  | 'site_manager'
  | 'accountant'
  | 'engineer'
  | 'foreman';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  siteAccess?: string[];
  phone?: string;
  profileImage?: string;
  active: boolean;
}

export interface Site {
  id: string;
  name: string;
  location: string;
  status: 'active' | 'inactive' | 'completed';
  startDate: string;
  budget: number;
  spent: number;
  progress: number;
  manager?: string;
}

export interface Task {
  id: string;
  title: string;
  description: string;
  siteId: string;
  siteName: string;
  assignedTo: string[];
  status: 'pending' | 'in_progress' | 'completed';
  priority: 'low' | 'medium' | 'high';
  dueDate: string;
  progress: number;
  createdAt: string;
  updatedAt: string;
  photos?: string[];
}

export interface Survey {
  id: string;
  type: string;
  siteId: string;
  siteName: string;
  surveyorId: string;
  measurements: Record<string, any>;
  location?: {
    latitude: number;
    longitude: number;
  };
  photos?: string[];
  status: 'draft' | 'submitted' | 'approved';
  createdAt: string;
}

export interface Operation {
  id: string;
  name: string;
  siteId: string;
  siteName: string;
  type: string;
  status: 'planned' | 'ongoing' | 'completed';
  budget: number;
  spent: number;
  startDate: string;
  endDate?: string;
  crew: string[];
}

export interface Report {
  id: string;
  title: string;
  type: 'financial' | 'operations' | 'site_performance';
  generatedDate: string;
  period: string;
  data: any;
}

import { Site, Task, Survey, Operation, Report } from '@/types';

export const mockSites: Site[] = [
  {
    id: 'site1',
    name: 'Kigali-Rwamagana Highway',
    location: 'Eastern Province',
    status: 'active',
    startDate: '2024-01-15',
    budget: 5000000,
    spent: 3200000,
    progress: 64,
    manager: 'John Manager',
  },
  {
    id: 'site2',
    name: 'Musanze Road Expansion',
    location: 'Northern Province',
    status: 'active',
    startDate: '2024-02-01',
    budget: 3500000,
    spent: 1750000,
    progress: 50,
    manager: 'Sarah Engineer',
  },
  {
    id: 'site3',
    name: 'Huye Bridge Construction',
    location: 'Southern Province',
    status: 'active',
    startDate: '2024-03-10',
    budget: 2800000,
    spent: 840000,
    progress: 30,
    manager: 'David Foreman',
  },
];

export const mockTasks: Task[] = [
  {
    id: 'task1',
    title: 'Deliver Construction Materials',
    description: 'Transport cement and steel to site location',
    siteId: 'site1',
    siteName: 'Kigali-Rwamagana Highway',
    assignedTo: ['3'],
    status: 'in_progress',
    priority: 'high',
    dueDate: '2024-12-20',
    progress: 45,
    createdAt: '2024-12-15',
    updatedAt: '2024-12-18',
    photos: [],
  },
  {
    id: 'task2',
    title: 'Transport Gravel Load',
    description: 'Move 10 tons of gravel from quarry to site',
    siteId: 'site2',
    siteName: 'Musanze Road Expansion',
    assignedTo: ['3'],
    status: 'pending',
    priority: 'medium',
    dueDate: '2024-12-22',
    progress: 0,
    createdAt: '2024-12-16',
    updatedAt: '2024-12-16',
  },
  {
    id: 'task3',
    title: 'Final Inspection Drive',
    description: 'Complete final quality check on section A',
    siteId: 'site1',
    siteName: 'Kigali-Rwamagana Highway',
    assignedTo: ['3'],
    status: 'completed',
    priority: 'low',
    dueDate: '2024-12-17',
    progress: 100,
    createdAt: '2024-12-10',
    updatedAt: '2024-12-17',
  },
];

export const mockSurveys: Survey[] = [
  {
    id: 'survey1',
    type: 'Ground Level Survey',
    siteId: 'site1',
    siteName: 'Kigali-Rwamagana Highway',
    surveyorId: '4',
    measurements: {
      elevation: '1450m',
      slope: '3.2%',
      soilType: 'Clay',
    },
    location: {
      latitude: -1.9403,
      longitude: 29.8739,
    },
    photos: [],
    status: 'submitted',
    createdAt: '2024-12-18',
  },
];

export const mockOperations: Operation[] = [
  {
    id: 'op1',
    name: 'Base Layer Construction',
    siteId: 'site1',
    siteName: 'Kigali-Rwamagana Highway',
    type: 'Road Foundation',
    status: 'ongoing',
    budget: 1200000,
    spent: 850000,
    startDate: '2024-11-01',
    crew: ['John Doe', 'Jane Smith', 'Bob Worker'],
  },
  {
    id: 'op2',
    name: 'Bridge Foundation',
    siteId: 'site3',
    siteName: 'Huye Bridge Construction',
    type: 'Foundation Work',
    status: 'ongoing',
    budget: 800000,
    spent: 320000,
    startDate: '2024-12-01',
    crew: ['Mike Builder', 'Alice Mason'],
  },
];

export const mockReports: Report[] = [
  {
    id: 'report1',
    title: 'Q4 2024 Financial Summary',
    type: 'financial',
    generatedDate: '2024-12-18',
    period: 'Q4 2024',
    data: {
      totalBudget: 11300000,
      totalSpent: 5790000,
      remainingBudget: 5510000,
    },
  },
  {
    id: 'report2',
    title: 'Site Operations Overview',
    type: 'operations',
    generatedDate: '2024-12-18',
    period: 'December 2024',
    data: {
      activeSites: 3,
      completedTasks: 12,
      pendingTasks: 8,
    },
  },
];

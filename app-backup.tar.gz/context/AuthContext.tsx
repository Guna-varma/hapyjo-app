import React, { createContext, useContext, useState, ReactNode } from 'react';
import { User } from '@/types';

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Mock users for demonstration
const mockUsers: Record<string, User> = {
  'admin@hapyjo.rw': {
    id: '1',
    name: 'Admin User',
    email: 'admin@hapyjo.rw',
    role: 'admin',
    active: true,
  },
  'owner@hapyjo.rw': {
    id: '2',
    name: 'Business Owner',
    email: 'owner@hapyjo.rw',
    role: 'owner',
    active: true,
  },
  'driver@hapyjo.rw': {
    id: '3',
    name: 'John Driver',
    email: 'driver@hapyjo.rw',
    role: 'driver',
    siteAccess: ['site1', 'site2'],
    active: true,
  },
  'surveyor@hapyjo.rw': {
    id: '4',
    name: 'Mary Surveyor',
    email: 'surveyor@hapyjo.rw',
    role: 'surveyor',
    siteAccess: ['site1'],
    active: true,
  },
};

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  const login = async (email: string, password: string) => {
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 500));
    
    const foundUser = mockUsers[email.toLowerCase()];
    if (foundUser) {
      setUser(foundUser);
    } else {
      throw new Error('Invalid credentials');
    }
  };

  const logout = () => {
    setUser(null);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        login,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
